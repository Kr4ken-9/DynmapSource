<?php 
	$users = array(
			"Admin" => array("Administrator", "admin"),

			//To add more people add another array in format ---> "<Username>" => array("<Password>", "<Group>"),
			//For now groups are only admin and user, they are not used yet, but they will be used in the future
		)
?>