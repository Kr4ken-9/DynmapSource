<?php
	$privatekey = "MySecretPrivateKey"; //Private key, must match with key in plugin config!
	$syncinterval = 5000; //Interval to sync positions and names of players with server in miliseconds
	$DynmapTitle = "Unturned Dynmap"; //Title which will be shown on the tab
	$backgroundColor = "black"; //Background color of the map => color of bars on the sides
	$loginbackground = "http://unturned.linhy.cz/loginbackground.png"; //Default login background image
	$serverIP = ""; //IP address of server without port
	$serverPort = ""; //Port of the server
	$login = true; //Set true, if you want users to login to access dynmap, otherwise set false
?>